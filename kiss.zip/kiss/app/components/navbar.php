<header class="NavBar">
  <section class="NavBar-container">
    <?php require_once './app/components/logo.php'; ?>
    <button class="NavBar-btn  hamburger  hamburger--emphatic" type="button">
      <span class="hamburger-box">
        <span class="hamburger-inner"></span>
      </span>
    </button>
    <section class="NavBar-panel">
      <?php require_once './app/components/menu.php'; ?>
    </section>
  </section>
</header>
