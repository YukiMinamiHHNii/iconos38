<nav class="Menu">
  <ul>
    <li><a href="<?=APP['home_url']?>">Home</a></li>
    <li><a href="<?=APP['home_url']?>/acerca">Acerca</a></li>
    <li><a href="<?=APP['home_url']?>/contacto">Contacto</a></li>
    <li><a href="<?=APP['home_url']?>/no-existe">No Existe</a></li>
  </ul>
</nav>
