<?php
$meta_title =  'Error 404: Not Found';
$meta_description = 'Lo sentimos, NO se encuentra el contenido que solicitas.';
$meta_img = './img/error-404.png';
$meta_url = null;
