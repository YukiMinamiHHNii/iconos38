<?php
$meta_title =  'Título del Home';
$meta_description = 'Descripción del Home.';
$meta_img = './img/meta-home.jpg';
$meta_url = $_SERVER["HTTP_HOST"] .  $_SERVER["REQUEST_URI"];
