<?php
$meta_title =  'Título de Contacto';
$meta_description = 'Descripción de Contacto.';
$meta_img = './img/meta-contacto.jpg';
$meta_url = $_SERVER["HTTP_HOST"] .  $_SERVER["REQUEST_URI"];
