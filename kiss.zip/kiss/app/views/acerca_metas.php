<?php
$meta_title =  'Título de Acerca';
$meta_description = 'Descripción de Acerca.';
$meta_img = './img/meta-acerca.jpg';
$meta_url = $_SERVER["HTTP_HOST"] .  $_SERVER["REQUEST_URI"];
